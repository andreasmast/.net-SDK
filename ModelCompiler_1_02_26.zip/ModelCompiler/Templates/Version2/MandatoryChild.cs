class _Name_{ public void Method() {
// ***START***
_ChildName_ = _TypeName_State.Construct_ChildName_(context, this);
_ChildName_.CreateInstance(context, isDeclaration);
// ***END***
} }