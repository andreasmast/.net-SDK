class _Name_{
// ***START***
/// <summary>
/// The identifier for the _SymbolicName_ _NodeClass_.
/// </summary>
public const uint _SymbolicName_ = _Identifier_;
// ***END***
}