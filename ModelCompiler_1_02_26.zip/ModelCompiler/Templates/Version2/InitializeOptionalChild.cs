class _Name_{ public void Method(int x) {
// ***START***
if (_ChildName_ != null)
{
    _ChildName_.Initialize(context, _ChildName__InitializationString);
}
// ***END***
} }