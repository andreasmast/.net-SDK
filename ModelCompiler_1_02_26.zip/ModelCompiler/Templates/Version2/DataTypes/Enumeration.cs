// ***START***
#region _BrowseName_ Enumeration
#if (!OPCUA_EXCLUDE__BrowseName_)
/// <summary>
/// _Description_
/// </summary>
/// <exclude />
[System.CodeDom.Compiler.GeneratedCodeAttribute("Opc.Ua.ModelCompiler", "1.0.0.0")]
[DataContract(Namespace = _XmlNamespaceUri_)]
public enum _BrowseName_
{
    // ListOfProperties
}
// CollectionClass
#endif
#endregion
// ***END***