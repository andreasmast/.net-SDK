enum Placeholder {
// ***START***
/// <summary>
/// _Description_
/// </summary>
[EnumMember(Value = "_XmlIdentifier_")]
_BrowseName_ = _Identifier_,
// ***END***
}