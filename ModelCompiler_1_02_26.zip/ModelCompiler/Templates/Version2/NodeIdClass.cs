// ***START***
#region _NodeClass_ Node Identifiers
/// <summary>
/// A class that declares constants for all _NodeClass_s in the Model Design.
/// </summary>
/// <exclude />
[System.CodeDom.Compiler.GeneratedCodeAttribute("Opc.Ua.ModelCompiler", "1.0.0.0")]
public static partial class _NodeClass_Ids
{
    // ListOfIdentifiers
}
#endregion
// ***END***
