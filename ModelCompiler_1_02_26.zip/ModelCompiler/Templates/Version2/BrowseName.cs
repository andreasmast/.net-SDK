class _Name_{
// ***START***
/// <summary>
/// The BrowseName for the _SymbolicName_ component.
/// </summary>
public const string _SymbolicName_ = "_BrowseName_";
// ***END***
}