class _Name_{ public void Method() {
// ***START***
if (_FieldName_ != null)
{
    children.Add(_FieldName_);
}
// ***END***
} }