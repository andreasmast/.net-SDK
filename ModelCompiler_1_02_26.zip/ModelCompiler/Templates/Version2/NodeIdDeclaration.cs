class _Name_{
// ***START***
/// <summary>
/// The identifier for the _SymbolicName_ _NodeClass_.
/// </summary>
public static readonly NodeId _SymbolicName_ = new NodeId(_NamespacePrefix_._NodeClass_s._SymbolicName_);
// ***END***
}