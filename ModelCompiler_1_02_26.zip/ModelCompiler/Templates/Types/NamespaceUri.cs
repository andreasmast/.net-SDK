class _Name_ {
// ***START***
/// <summary>
/// The URI for the _Name_ namespace (.NET code namespace is '_CodeName_').
/// </summary>
public const string _Name_ = "_NamespaceUri_";
// ***END***
}