// ***START***
using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using System.Xml;
// ListOfImports

namespace _Namespace_
{
    /// <summary>
    /// Defines constants for all namespace referenced by the model design.
    /// </summary>
    /// <exclude />
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Opc.Ua.ModelCompiler", "1.0.0.0")]
    public static partial class Namespaces
    {
        // ListOfNamespaceUris
    }
}
// ***END***
