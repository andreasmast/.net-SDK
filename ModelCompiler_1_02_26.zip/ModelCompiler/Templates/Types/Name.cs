class _Name_ {
// ***START***
/// <summary>
/// The browse name for the _SymbolicId_ node.
/// </summary>
public const string _SymbolicId_ = "_BrowseName_";
// ***END***
}