// ***START***
using System;
using System.Collections.Generic;
using System.Text;
// ListOfImports

namespace _Namespace_
{
    /// <summary>
    /// Defines constants for all names in the model.
    /// </summary>
    /// <exclude />
    [System.CodeDom.Compiler.GeneratedCodeAttribute("Opc.Ua.ModelCompiler", "1.0.0.0")]
    public static partial class Names
    {
        // ListOfNames
    }
}
// ***END***
