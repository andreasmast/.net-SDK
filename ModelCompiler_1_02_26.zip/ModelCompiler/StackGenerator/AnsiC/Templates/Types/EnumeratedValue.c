hstatic struct _OpcUa_EnumeratedValue g__TYPE__EnumeratedValues[] =
{
// ***START***
{ "_Name_", _Value_ },
// ***END***
};