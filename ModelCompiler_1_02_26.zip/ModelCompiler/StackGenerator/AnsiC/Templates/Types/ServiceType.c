// ***START***
#ifndef OPCUA_EXCLUDE__NAME_
// _RequestMessage_

// _ResponseMessage_
#endif
// ***END***