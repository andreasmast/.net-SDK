// ***START***
#ifndef OPCUA_EXCLUDE__NAME_
/*============================================================================
 * _TYPE__EnumeratedType
 *===========================================================================*/
static struct _OpcUa_EnumeratedValue g__TYPE__EnumeratedValues[] =
{
    // _ValueStringList_
    { OpcUa_Null, 0 }
};

struct _OpcUa_EnumeratedType _TYPE__EnumeratedType =
{
    "_NAME_",
    g__TYPE__EnumeratedValues
};
#endif
// ***END***