// ***START***
    { &hf_opcua__NAME_,
    {  "_NAME_", "", FT_UINT32, BASE_HEX,  VALS(g__NAME_Table), 0x0, "", HFILL }
    }
// ***END***