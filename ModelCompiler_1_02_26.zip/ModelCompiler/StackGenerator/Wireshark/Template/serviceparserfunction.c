// ***START***

gint ett_opcua__NAME_ = -1;
void parse_NAME_(proto_tree *tree, tvbuff_t *tvb, gint *pOffset)
{
  proto_item *ti = proto_tree_add_text(tree, tvb, 0, -1, "_NAME_");
  proto_tree *subtree = proto_item_add_subtree(ti, ett_opcua__NAME_);

// _FIELDS_
}

// ***END***
