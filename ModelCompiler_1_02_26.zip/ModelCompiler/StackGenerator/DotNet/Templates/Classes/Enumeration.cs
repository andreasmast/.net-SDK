// ***START***
#region _NAME_ Enumeration
#if (!OPCUA_EXCLUDE__NAME_)
/// <summary>
/// The _NAME_ enumeration.
/// </summary>
/// <exclude />
// _XMLTYPE_
[System.CodeDom.Compiler.GeneratedCodeAttribute("Opc.Ua.CodeGenerator", "1.0.0.0")]
public enum _NAME_
{
    // _VALUELIST_
}
// _ENUMCOLLECTIONCLASS_
#endif
#endregion
// ***END***