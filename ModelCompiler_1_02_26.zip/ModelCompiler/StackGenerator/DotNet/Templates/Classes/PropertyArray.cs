class Placeholder
{
// ***START***
/// <summary>
/// The _EXTERNALNAME_ property.
/// </summary>
// _XMLTYPE_
public _TYPE_ _EXTERNALNAME_
{
    get { return m__INTERNALNAME_;  }

    set
    {
        if (value != null)
        {
            m__INTERNALNAME_ = value;
        }
        else
        {
            m__INTERNALNAME_ = new _TYPE_();
        }
    }
}
// ***END***

}
