class Placeholder
{
// ***START***
/// <summary>
/// The _EXTERNALNAME_ property.
/// </summary>
// _XMLTYPE_
public _TYPE_ _EXTERNALNAME_
{
    get { return m__INTERNALNAME_;  }
    set { m__INTERNALNAME_ = value; }
}
// ***END***

}
