enum Placeholder
{
// ***START***
/// <summary>
/// _NAME_ = _VALUE_
/// </summary>
// _XMLTYPE_
_NAME_ = _VALUE_
// ***END***
}