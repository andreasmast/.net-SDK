class Placeholder
{
// ***START***
/// <summary>
/// _Description_
/// </summary>
public const _IdType_ _SymbolicId_ = _Identifier_;
// ***END***
}