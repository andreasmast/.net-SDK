class Placeholder
{
// ***START***
/*============================================================================
 * The identifier for the XML encoding of the _SymbolicId_ datatype.
 *===========================================================================*/
#define OpcUa_ClassName___SymbolicId__Encoding_DefaultXml _XmlEncodingId_

/*============================================================================
 * The identifier for the UA Binary encoding of the _SymbolicId_ datatype.
 *===========================================================================*/
#define OpcUa_ClassName___SymbolicId__Encoding_DefaultBinary _BinaryEncodingId_
// ***END***
}