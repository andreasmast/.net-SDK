/* ========================================================================
 * Copyright (c) 2005-2011 The OPC Foundation, Inc. All rights reserved.
 *
 * OPC Reciprocal Community License ("RCL") Version 1.00
 *
 * Unless explicitly acquired and licensed from Licensor under another
 * license, the contents of this file are subject to the Reciprocal
 * Community License ("RCL") Version 1.00, or subsequent versions
 * as allowed by the RCL, and You may not copy or use this file in either
 * source code or executable form, except in compliance with the terms and
 * conditions of the RCL.
 *
 * All software distributed under the RCL is provided strictly on an
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * AND LICENSOR HEREBY DISCLAIMS ALL SUCH WARRANTIES, INCLUDING WITHOUT
 * LIMITATION, ANY WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, QUIET ENJOYMENT, OR NON-INFRINGEMENT. See the RCL for specific
 * language governing rights and limitations under the RCL.
 *
 * The complete license agreement can be found here:
 * http://opcfoundation.org/License/RCL/1.00/
 * ======================================================================*/

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace Opc.Ua
{
    /// <summary>
    /// Defines functions used to encode objects in a stream.
    /// </summary>
    public interface IEncoder
    {
        /// <summary>
        /// The type of encoding being used.
        /// </summary>
        EncodingType EncodingType { get; }

        /// <summary>
        /// The message context associated with the encoder.
        /// </summary>
        ServiceMessageContext Context { get; }

        /// <summary>
        /// Pushes a namespace onto the namespace stack.
        /// </summary>
        void PushNamespace(string namespaceUri);

        /// <summary>
        /// Pops a namespace from the namespace stack.
        /// </summary>
        void PopNamespace();

        /// <summary>
        /// Writes a boolean to the stream.
        /// </summary>
        void WriteBoolean(string fieldName, bool value);

        /// <summary>
        /// Writes a sbyte to the stream.
        /// </summary>
        void WriteSByte(string fieldName, sbyte value);

        /// <summary>
        /// Writes a byte to the stream.
        /// </summary>
        void WriteByte(string fieldName, byte value);

        /// <summary>
        /// Writes a short to the stream.
        /// </summary>
        void WriteInt16(string fieldName, short value);

        /// <summary>
        /// Writes a ushort to the stream.
        /// </summary>
        void WriteUInt16(string fieldName, ushort value);

        /// <summary>
        /// Writes an int to the stream.
        /// </summary>
        void WriteInt32(string fieldName, int value);

        /// <summary>
        /// Writes a uint to the stream.
        /// </summary>
        void WriteUInt32(string fieldName, uint value);

        /// <summary>
        /// Writes a long to the stream.
        /// </summary>
        void WriteInt64(string fieldName, long value);

        /// <summary>
        /// Writes a ulong to the stream.
        /// </summary>
        void WriteUInt64(string fieldName, ulong value);

        /// <summary>
        /// Writes a float to the stream.
        /// </summary>
        void WriteFloat(string fieldName, float value);

        /// <summary>
        /// Writes a double to the stream.
        /// </summary>
        void WriteDouble(string fieldName, double value);

        /// <summary>
        /// Writes a string to the stream.
        /// </summary>
        void WriteString(string fieldName, string value);

        /// <summary>
        /// Writes a UTC date/time to the stream.
        /// </summary>
        void WriteDateTime(string fieldName, DateTime value);

        /// <summary>
        /// Writes a GUID to the stream.
        /// </summary>
        void WriteGuid(string fieldName, Uuid value);

        /// <summary>
        /// Writes a GUID to the stream.
        /// </summary>
        void WriteGuid(string fieldName, Guid value);

        /// <summary>
        /// Writes a byte string to the stream.
        /// </summary>
        void WriteByteString(string fieldName, byte[] value);

        /// <summary>
        /// Writes an XmlElement to the stream.
        /// </summary>
        void WriteXmlElement(string fieldName, XmlElement value);

        /// <summary>
        /// Writes an NodeId to the stream.
        /// </summary>
        void WriteNodeId(string fieldName, NodeId value);

        /// <summary>
        /// Writes an ExpandedNodeId to the stream.
        /// </summary>
        void WriteExpandedNodeId(string fieldName, ExpandedNodeId value);

        /// <summary>
        /// Writes an StatusCode to the stream.
        /// </summary>
        void WriteStatusCode(string fieldName, StatusCode value);

        /// <summary>
        /// Writes an DiagnosticInfo to the stream.
        /// </summary>
        void WriteDiagnosticInfo(string fieldName, DiagnosticInfo value);

        /// <summary>
        /// Writes an QualifiedName to the stream.
        /// </summary>
        void WriteQualifiedName(string fieldName, QualifiedName value);

        /// <summary>
        /// Writes an LocalizedText to the stream.
        /// </summary>
        void WriteLocalizedText(string fieldName, LocalizedText value);

        /// <summary>
        /// Writes an Variant array to the stream.
        /// </summary>
        void WriteVariant(string fieldName, Variant value);

        /// <summary>
        /// Writes an DataValue array to the stream.
        /// </summary>
        void WriteDataValue(string fieldName, DataValue value);

        /// <summary>
        /// Writes an ExtensionObject to the stream.
        /// </summary>
        void WriteExtensionObject(string fieldName, ExtensionObject value);

        /// <summary>
        /// Writes an encodeable object to the stream.
        /// </summary>
        void WriteEncodeable(string fieldName, IEncodeable value, System.Type systemType);

        /// <summary>
        /// Writes an enumerated value array to the stream.
        /// </summary>
        void WriteEnumerated(string fieldName, Enum value);

        /// <summary>
        /// Writes a boolean array to the stream.
        /// </summary>
        void WriteBooleanArray(string fieldName, IList<bool> values);

        /// <summary>
        /// Writes a sbyte array to the stream.
        /// </summary>
        void WriteSByteArray(string fieldName, IList<sbyte> values);

        /// <summary>
        /// Writes a sbyte array to the stream.
        /// </summary>
        void WriteByteArray(string fieldName, IList<byte> values);

        /// <summary>
        /// Writes a short array to the stream.
        /// </summary>
        void WriteInt16Array(string fieldName, IList<short> values);

        /// <summary>
        /// Writes a ushort array to the stream.
        /// </summary>
        void WriteUInt16Array(string fieldName, IList<ushort> values);

        /// <summary>
        /// Writes a int array to the stream.
        /// </summary>
        void WriteInt32Array(string fieldName, IList<int> values);

        /// <summary>
        /// Writes a uint array to the stream.
        /// </summary>
        void WriteUInt32Array(string fieldName, IList<uint> values);

        /// <summary>
        /// Writes a long array to the stream.
        /// </summary>
        void WriteInt64Array(string fieldName, IList<long> values);

        /// <summary>
        /// Writes a ulong array to the stream.
        /// </summary>
        void WriteUInt64Array(string fieldName, IList<ulong> values);

        /// <summary>
        /// Writes a float array to the stream.
        /// </summary>
        void WriteFloatArray(string fieldName, IList<float> values);

        /// <summary>
        /// Writes a double array to the stream.
        /// </summary>
        void WriteDoubleArray(string fieldName, IList<double> values);

        /// <summary>
        /// Writes a string array to the stream.
        /// </summary>
        void WriteStringArray(string fieldName, IList<string> values);

        /// <summary>
        /// Writes a UTC date/time array to the stream.
        /// </summary>
        void WriteDateTimeArray(string fieldName, IList<DateTime> values);

        /// <summary>
        /// Writes a GUID array to the stream.
        /// </summary>
        void WriteGuidArray(string fieldName, IList<Uuid> values);

        /// <summary>
        /// Writes a GUID array to the stream.
        /// </summary>
        void WriteGuidArray(string fieldName, IList<Guid> values);

        /// <summary>
        /// Writes a byte string array to the stream.
        /// </summary>
        void WriteByteStringArray(string fieldName, IList<byte[]> values);

        /// <summary>
        /// Writes a XmlElement array to the stream.
        /// </summary>
        void WriteXmlElementArray(string fieldName, IList<XmlElement> values);

        /// <summary>
        /// Writes an NodeId array to the stream.
        /// </summary>
        void WriteNodeIdArray(string fieldName, IList<NodeId> values);

        /// <summary>
        /// Writes an ExpandedNodeId array to the stream.
        /// </summary>
        void WriteExpandedNodeIdArray(string fieldName, IList<ExpandedNodeId> values);

        /// <summary>
        /// Writes an StatusCode array to the stream.
        /// </summary>
        void WriteStatusCodeArray(string fieldName, IList<StatusCode> values);

        /// <summary>
        /// Writes an DiagnosticInfo array to the stream.
        /// </summary>
        void WriteDiagnosticInfoArray(string fieldName, IList<DiagnosticInfo> values);

        /// <summary>
        /// Writes an QualifiedName array to the stream.
        /// </summary>
        void WriteQualifiedNameArray(string fieldName, IList<QualifiedName> values);

        /// <summary>
        /// Writes an LocalizedText array to the stream.
        /// </summary>
        void WriteLocalizedTextArray(string fieldName, IList<LocalizedText> values);

        /// <summary>
        /// Writes an Variant array to the stream.
        /// </summary>
        void WriteVariantArray(string fieldName, IList<Variant> values);

        /// <summary>
        /// Writes an DataValue array to the stream.
        /// </summary>
        void WriteDataValueArray(string fieldName, IList<DataValue> values);

        /// <summary>
        /// Writes an extension object array to the stream.
        /// </summary>
        void WriteExtensionObjectArray(string fieldName, IList<ExtensionObject> values);

        /// <summary>
        /// Writes an encodeable object array to the stream.
        /// </summary>
        void WriteEncodeableArray(string fieldName, IList<IEncodeable> values, System.Type systemType);

        /// <summary>
        /// Writes an enumerated value array to the stream.
        /// </summary>
        void WriteEnumeratedArray(string fieldName, Array values, System.Type systemType);
    }

    /// <summary>
    /// The type of encoding used by an encoder/decoder.
    /// </summary>
    public enum EncodingType
    {
        /// <summary>
        /// The UA Binary encoding.
        /// </summary>
        Binary,

        /// <summary>
        /// XML
        /// </summary>
        Xml
    }
}
